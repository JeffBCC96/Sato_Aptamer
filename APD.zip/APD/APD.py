import os, sys, re, zipfile, shutil,optparse
from Bio.Blast import NCBIWWW, NCBIXML
from Bio import SeqIO, Entrez, pairwise2
from collections import OrderedDict


def search_feature_index(gene_bank_record, feature_type):
    """search for CDS region in gene_bank file and return the index"""
    for index, feature in enumerate(gene_bank_record.features):
        # print (feature.type)
        if feature.type == feature_type:
            return index

    print("Can not find the feature")
    return None


def CDS_fasta(name, file_type, seq, gb_record=''):
    """ create fasta file for gene_bank file or input sequence"""
    with open(name, "w") as f:
        if file_type == "gene_bank":
            f.write(f">{gb_record.id} {gb_record.description} \n")

        elif file_type == "":
            f.write(f">{name} \n")

        f.write(seq)
        f.close()


# parse the useful information of the txt file
def parsing_useful_region(sequence, txt_file):
    """ parse unstructured region through the result of SPARCS"""
    satisfied_region = []
    segments = [] 
    with open(txt_file, "r") as f:
        for i in f:
            if "Unstructured regions using dinucleotide model" in i:
                U_dinucleotide_model = i

    new_string = ""
    for index, value in enumerate(U_dinucleotide_model):
        if value == ":":
            new_string = U_dinucleotide_model[index + 3:-2]

    char = ["[", "]", " "]
    for item in char:
        nn = new_string.replace(item, "")
        new_string = nn

    new_string = new_string.split(",")
    

    if len(new_string) % 2 != 0:
        print("wrong info")

    for i in range(0, len(new_string), 2):
        segments.append((int(new_string[i]), int(new_string[i+1])))
    
    
    at_least_one = 0
    for i in segments: 
        if i[1] - i[0] > 24: 
            at_least_one += 1
            
            
    if at_least_one >= 1: 
        segments = [i for i in segments if not (i[1]-i[0] < 24 or i[1]-i[0] >200)]
        
    
    elif at_least_one == 0 and len(segments) != 0:
        left = segments[0][0]
        right = segments[0][1] 
        for i in range(16):
            for x in range(16):
                if left-i >= 0 and right + x < len(sequence) and (right+x) - (left-i) >= 26: 
                    segments[0] = (left - i,right + x)
                    break 
        
    
    for i in segments:
        satisfied_region.append(sequence[i[0]:i[1]])

    satisfied_region = sorted(satisfied_region, key=lambda x: len(x))

    return satisfied_region



def c_folder_seq(l_seq, tp=''):
    """ create folders for NUPACK"""
    if tp == 'rna':
        path = os.getcwd() + "/self_compare"
    if tp == 'aptamer':
        path = os.getcwd() + "/aptamer_alone"

    os.mkdir(path)
    for index, item in enumerate(l_seq):
        with open(path + f"/{index}.in", "w") as f:
            f.write(l_seq[index])
        f.close()


def compare_RNA_itself(l_seq):
    """ create fasta file for gene_bank file or input sequence"""
    sequence_with_energy = []
    for i in range(len(l_seq)):
        name = f"{os.getcwd()}/self_compare/{i}.in"
        cod_path = f"{os.getcwd()}/self_compare/{i}"
        with open(name, "r") as f:
            seq = f.readline()
        f.close()

        cod = "pfunc -pseudo -material rna1999 " + cod_path
        result = os.popen(cod).read()
        rs = result.split("%")

        energy_value = float(rs[-1].split("\n")[1])
        sequence_with_energy.append((seq,energy_value))
    
    sequence_with_energy = sorted(sequence_with_energy, key=lambda x: x[1], reverse = True)

    return sequence_with_energy


def correct_format(file_name):
    """ correct the length of the input sequence """
    seq = ""
    with open(file_name, "r") as f:
        for i in f:
            if i.startswith(">") and i != '':
                name = i.rstrip()
            else:
                seq += i.rstrip()
    f.close()

    if len(seq) % 3:
        seq = seq[:len(seq) - (len(seq) % 3)]

    os.remove(file_name)

    with open(file_name, "w") as t:
        t.write(name + '\n')
        t.write(seq)
    t.close()


# part 2 functions here!
def complementary(seq):
    """ create complementary homology arms"""
    seq = seq.upper()
    new = ""
    for i in seq:
        if i == "A":
            i = "U"
        elif i == "U" or i == "T":
            i = "A"
        elif i == "G":
            i = "C"
        elif i == "C":
            i = "G"
        new += i

    return new


def aptamer_design(tar_seq, fp):
    """ design the SATO aptamers """
    if len(tar_seq) < 24:
        print("not enough length")

    aptamer_list = []
    
    flexible_part = [('UG','UU'),('UG','GU'),('UG','GG'),('UG','UG'),('UA','CC'),('UA','CG'),('UA','GG'),('UA','GC'),
                    ('UC','CC'),('UC','CU'),('UC','UC'),('UC','UU'),('UU','CC'),('UU','CG'),('UU','CU'),('UU','GC'),
                    ('UU','GG'),('UU','GU'),('UU','UC'),('UU','UG'),('UU','UU'),('AA','AA'),('AA','AC'),('AA','AG'),
                    ('AA','CA'),('AA','CC'),('AA','CG'),('AA','GA'),('AA','GC'),('AA','GG'),('AC','AA'),('AC','AC'),
                    ('AC','CC'),('AC','CA'),('AG','AA'),('AG','AG'),('AG','GA'),('AG','GG'),('AU','CC'),('AU','CG'),
                    ('AU','GG'),('AU','GC')]
    
    Sato_core = flexible_part[fp][0] + "GCCUAGAUAAAUUCGGAGC" + flexible_part[fp][1]
    

    core_first = 10

    for i in range(len(tar_seq)):
        if core_first + 13 + i > len(tar_seq) - 1:
            break

        left_arm = complementary(tar_seq[core_first + 4 + i: core_first + 14 + i][::-1])
        right_arm = complementary(tar_seq[0 + i: core_first + i][::-1])
        designed_aptamer = left_arm + Sato_core + right_arm
        designed_aptamer_reverse = left_arm + Sato_core[::-1] + right_arm
        aptamer_list.append(designed_aptamer)
        aptamer_list.append(designed_aptamer_reverse)

    return aptamer_list

def info_species (current_path, seq):
    """BLAST the homology arms"""
    result_here = NCBIWWW.qblast("blastn", "nt", seq, expect=100000.0, word_size=7)
    blast_r = NCBIXML.parse(result_here)
    path_info = current_path + "/info_species"
    f = open(path_info, "a+")

    hsp_threshold = 100000
    species = []
    for b in blast_r:
        for alignment in b.alignments:
            for hsp in alignment.hsps:
                if hsp.expect < hsp_threshold:
                    species.append(alignment.title.split("|")[4].split(',')[0].replace("PREDICTED: ", "").lstrip())
                    f.write(f"****Alignment****\nsequence: {alignment.title}\nlength: {alignment.length}\ne value: {hsp.expect}\n\
{hsp.query[0:75]}... \n{hsp.match[0:75]}... \n{hsp.sbjct[0:75]}...\n\n")

    f.close()
    
    for index, item in enumerate(species):
        species[index] = re.sub(r'\([^)]*\)', '', item).rstrip()

    species = list(OrderedDict.fromkeys(species))

    with open(path_info, "r+") as x:
        content = x.read()
        x.seek(0, 0)
        x.write(f"There are {len(species)} different species related to this sequence({seq}): \n\n")
        for i in species:
            x.write(i + "\n")
        x.write(f"\n{content}")
    x.close()



    
    
def c_structure_file(aptamer_list, target_seq, strand=2, max_complex=2):
    """ show the complex structure of the aptamer and RNA sequence """
    path = os.getcwd() + "/aptamer_compare"

    os.mkdir(path)
    for index, item in enumerate(aptamer_list):
        with open(path + f"/{index}.in", "w") as f:
            f.write(str(strand) + "\n")
            f.write(target_seq + "\n")
            f.write(aptamer_list[index] + "\n")
            f.write(str(max_complex))
        f.close()

        cod_path = f"complexes -mfe -material rna1999 {os.getcwd()}/aptamer_compare/{index}"
        os.popen(cod_path).read()

        
        
def compare_structure(t_ap_list):
    """ select the desired aptamers by comparing their complex structures """
    
    def format_convert(ap_lst):
        for index, i in enumerate(ap_lst):
            path = i[2]
            with open(path, "r") as f:
                f.readline()
                f.readline()
                ap_seq = f.readline().rstrip()
                ap_lst[index] = (i[0], i[1], ap_seq)
            f.close()

        return ap_lst
    

            
    rna = '((((((((((....(((((((((('
    ap_1 = '))))))))))..((((.((.....)))).))..))))))))))'
    ap_2 = '))))))))))..((.((((.....)).))))..))))))))))'
    
    lower_level_1 = ".((.((((.....)).))))."
    #lower_level_2 = ".((((.((.....)))).))."
    
    
#     required_structure_1 = "((((((((((....((((((((((+))))))))))..((((.((.....)))).))..))))))))))"
#     required_structure_2 = "((((((((((....((((((((((+))))))))))..((.((((.....)).))))..))))))))))"
    
    perfect_one, acceptable_one, total = [], [], []

    for index in range(len(t_ap_list)):
        ap_name = f"{os.getcwd()}/aptamer_compare/{index}.ocx-mfe"
        with open(ap_name, "r") as f:
            for i in f:
                if '(' in i.rstrip() and ')'in i.rstrip() and '+' in i.rstrip(): 
                    rna_part = i.rstrip()[0:i.rstrip().index('+')]
                    ap_part = i.rstrip()[i.rstrip().index('+')+1:]
                    
                    if rna in rna_part and (ap_part == ap_1 or ap_part == ap_2):
                        perfect_one.append((float(previousline.rstrip()), i.rstrip(), ap_name[:-7] + "in"))
    
                    elif lower_level_1 in i.rstrip():
                        acceptable_one.append((float(previousline.rstrip()), i.rstrip(), ap_name[:-7] + "in"))
                    
                previousline = i
        f.close()

    perfect_one = sorted(perfect_one, key=lambda x: x[0])
    acceptable_one = sorted(acceptable_one, key=lambda x: x[0])
    

        
    perfect_one = format_convert(perfect_one)
    acceptable_one = format_convert(acceptable_one)

    total.extend(perfect_one)
    total.extend(acceptable_one)
        
    return (perfect_one, acceptable_one, total)
        




# aptamer_alone!
def aptamer_alone(aptamer_list):
    """ test the free energy of the aptamer designed """
    aptamers= []
    for i in range(len(aptamer_list)):
        name = f"{os.getcwd()}/aptamer_alone/{i}.in"
        cod_path = f"{os.getcwd()}/aptamer_alone/{i}"
        with open(name, "r") as f:
            seq = f.readline()
        f.close()

        cod = "pfunc -pseudo -material rna1999 " + cod_path
        result = os.popen(cod).read()
        rs = result.split("%")

        energy_value = float(rs[-1].split("\n")[1])
        aptamers.append((energy_value,seq))

    return aptamers



def two_seq_compare(seq1, seq2):
    """ align two sequences and find the unique sections """
    alignments = pairwise2.align.globalms(seq1, seq2, 2, -1, -10, -.1)
    print(pairwise2.format_alignment(*alignments[0]))
    a1 = alignments[0]
    #('AAAAC-GT-GATAG-TG-AGTG', '-AAACCGTTG-T-GCTGTAGT-', 14.0, 0, 22)
    print (a1)
    
    difference = [] 
    num = 0
    for index,item in enumerate(a1[0]):
        if item != a1[1][index]:
            if (index + 1) < len(a1[0]): 
                if a1[0][index + 1] != a1[1][index+1] and num %2 == 0:  
                    difference.append(index)
                    num += 1
                if a1[0][index + 1] == a1[1][index+1]:
                    difference.append(index)
                    num += 1
    
    difference = [(difference[i], difference[i+1]) for i in range(0, len(difference), 2)]
    
        
    for index, item in enumerate(difference):
        for a in range(15,0, -1):
            if item[0]-a >0:
                start = item[0]-a
                for b in range(15, 0, -1):
                    if item[1]+ b < len(a1[0]) and item[1]+ b - (item[0]-a) + 1 >= 24:
                        stop = item[1]+ b
                        break
                    else:
                        continue
                                        
            else: 
                continue
            difference[index] = (start, stop)   
            break
                
    
    for index, item in enumerate(difference):
        print(item[0])
        print (item[1])
        if not '-' in seq1[item[0]:item[1]]:
            difference[0] = ('seq1', seq1[item[0]:item[1]], item)
        elif not '-' in seq2[item[0], item[1]]:
            difference[0] = ('seq2', seq1[item[0]:item[1]], item)
        else:
            print ('can not distinguish the difference')
            return False
    
    return difference


def final_result(ap_result, failed_one, only_seq):
    """ write down the result as well as the failed aptamers """
    current_path = str(os.getcwd())
    result_path = current_path+'/final_result'
    failed_path = current_path +'/failed_aptamers'
    
     
    if len(failed_one["failed_structure"]):
        for index, item in enumerate(failed_one["failed_structure"]):
            with open(failed_path, "a+") as r:
                if index == 0:
                    r.write("Here are the failed aptamers \nFail Reason: Can not form the desired structure.\n")
                    r.write("The target sequence is : " + only_seq + "\n")
                    r.write("The failed aptmaers designed is(are) : ")
                r.write('\n' + item + ",")
                r.write("\n")

 
    if len(failed_one["failed_self"]):
        for index, i in enumerate(failed_one["failed_structure"]):
            with open(failed_path, "a+") as r:
                if index == 0:
                    r.write("Fail Reason: Aptamer itself will form undesired structure\n")
                    # r.write("The target sequence is : " + only_seq + "\n")
                    r.write("The failed aptmaers designed is(are) : ")
                r.write(f'\n{i[1]} with the value {i[0]}\n')
                r.write("\n")
    
    print("------   failed aptamers done!   ------")
    
    if ap_result:
        if ap_result[0]:
            for index, i in enumerate(ap_result[0]):
                info_species(current_path, i[2][0:10] + 'NNNN' + i[2][33:])
                with open(result_path, "a+") as r:
                    if index == 0:
                        r.write("The target sequence is :" + only_seq + "\n")
                        r.write("Here are the preferred aptamer(s): \n")

                    r.write(f'{i[2]}, the structure is {i[1]} with free energy {i[0]}\n')
                    r.write("\n")
                r.close()
        
        if ap_result[1]:
            for index, i in enumerate(ap_result[1]):
                info_species(current_path, i[2][0:10] + 'NNNN' + i[2][33:])
                with open(result_path, "a+") as r:
                    if index == 0:
                        r.write("The target sequence is :" + only_seq + "\n")
                        r.write("Here are the accepted aptamer(s): \n")

                    r.write(f'{i[2]}, the structure is {i[1]} with free energy {i[0]}\n')
                    r.write("\n")
                r.close()
        print("------ successful aptamers done! ------")
        print("------        BLAST done!        ------")
        
    else: 
        with open(result_path, "w") as r:
            r.write("Sorry, no aptamers can be created or predicted based on the information")
        r.close()

        print("-----         NO results!        ------")
    




    # input can be fasta file, genebank file, sequence only, GI


# main function part !
#
#
#
#
#
def adt_main(name="", file_type="", gb_file="", file_name="", input_sequence="", GI=""):
    # name = "Cytohesin-1"
    # input_sequence = ""
    # gb_file = "KCTD10.gb.txt"
    # file_type = ""

    # if the input is fasta directly
    # file_name = ""

    # if the input is GI number
    # GI = 'xxxx'

    # _______________________________info required above____________________________________

    if file_type == "gene_bank" or GI:
        if GI:
            net_handle = Entrez.efetch(db="nucleotide", rettype="gb", retmode="text", id=GI)
            Entrez.email = "rong.ma2@mail.mcgill.ca"
            gb_file = GI + '.gb'
            gb = open(f"{gb_file}", "w")
            gb.write(net_handle.read())
            gb.close()
            net_handle.close()

        for gb_record in SeqIO.parse(open(gb_file, "r"), "genbank"):
            print("Name %s, %i features" % (gb_record.name, len(gb_record.features)))

            gb_feature = gb_record.features
            CDS = search_feature_index(gb_record, "CDS")

            feature_cds = gb_feature[CDS]
            cds_seq = feature_cds.location
            CDS_region = gb_record.seq[cds_seq.start: cds_seq.end]
            if len(CDS_region) % 3:
                CDS_region = CDS_region[:len(CDS_region)-(len(CDS_region) % 3)]

            file_name = gb_record.name + ".fa"
            CDS_fasta(file_name, file_type, str(CDS_region), gb_record)  # create a fasta file from genebank file



    # put the file into Sparcs.py
    elif file_type == "":
        file_name = name + ".fa"
        input_sequence = input_sequence.rstrip()
        if len(input_sequence)% 3:
            input_sequence = input_sequence[:len(input_sequence)-(len(input_sequence) % 3)]
        CDS_fasta(file_name, file_type, input_sequence)



    # check len of sequence in fasta
    elif file_type == 'fasta':
        correct_format(file_name)

    print("------ creating fasta file done! ------")

    # run sparcs.py! It only accept fasta files
    os.system("python2.7 sparcs.py  " + file_name)
    print("------   sparcs analysis done!   ------")

    # get the txt file after running sparcs
    if file_type == "gene_bank":
        txt_file = str(os.getcwd()) + "/" + gb_record.name + "/segmentsfile_" + gb_record.name + ".txt"
        folder = str(os.getcwd()) + "/" + gb_record.name

    elif file_type == "":
        txt_file = str(os.getcwd()) + "/" + name + "/segmentsfile_" + name + ".txt"
        folder = str(os.getcwd()) + "/" + name

    elif file_type == 'fasta':
        txt_file = str(os.getcwd()) + "/" + file_name[:-3] + "/segmentsfile_" + file_name[:-3] + ".txt"
        folder = str(os.getcwd()) + "/" + file_name[:-3]



    # parse the CDS sequence from fasta file
    with open(file_name, "r") as f:
        for i in f.readlines():
            if not i.startswith(">"):
                sequence = i

    # get the satisfied region
    regions = parsing_useful_region(sequence, txt_file)

    # select the best satisfied sequence and store info about species similarity

    c_folder_seq(regions, tp='rna')
    seq_lst = compare_RNA_itself(regions)
    for i in seq_lst: 
        if len(i[0]) < 24:
            seq_lst.remove(seq_lst[seq_lst.index(i)])
    
    print("------      RNA target done!     ------")
    # seq_lst contains all the selected sequences
#     sample [('CAACCTAGAGAAGAAGCGAGATGAGC', -0.586373966), ('TGTCCGTTCTCGAAGCAGTTATGATGAT', -1.35237129)] 
    #for index, seq in enumerate(seq_lst):
    
    #print(seq_lst)
    
    # here choose the first RNA sequence 
    only_seq = seq_lst[0][0]
    
    
    # design the aptamer with number of different flexiable parts (default: UG UU)
    for fp_num in range(21):
        
        t_ap_list = aptamer_design(only_seq, fp_num)
        c_structure_file(t_ap_list, only_seq)
        ap_result = compare_structure(t_ap_list)
        total_seq, f_ap_self = [], []

        if ap_result[2]:
            for i in ap_result[2]:
                total_seq.append(i[2])
            c_folder_seq(total_seq, tp='aptamer')
            ap_self = aptamer_alone(total_seq)

            for index, val in enumerate(ap_result[2]):
                if val[0] >= ap_self[index][0]:
                    f_ap_self.append(ap_self[index])

            shutil.rmtree(f"{os.getcwd()}/aptamer_alone")
        
        
        shutil.rmtree(f"{os.getcwd()}/aptamer_compare")
        # delete aptamers which are not satisfied for itself
        for i in f_ap_self:
            for item in ap_result[0]:
                if i[1] == item[2]:
                    ap_result[0].remove(item)

            for item in ap_result[1]:
                if i[1] == item[2]:
                    ap_result[1].remove(item)
        
        #print (f'ap_result \t {ap_result}')
        if len(ap_result[0]) != 0:
            break
            
        


    f_ap_structure = list(set(t_ap_list) - set(total_seq))

    failed_one = {"failed_self": f_ap_self, 'failed_structure': f_ap_structure}



    # here, transend 1. list of perfect, ac, failed(two types, only_seq)
    #f_result(perfect_one, acceptable_one, failed_one, only_seq, current_path)

    final_result(ap_result, failed_one, only_seq)    
    
    shutil.rmtree(f"{os.getcwd()}/self_compare")
    
    
    p1 = f'{file_name} {folder}'
    p2 = f'{os.getcwd()}/failed_aptamers {folder}'
    p3 = f'{os.getcwd()}/info_species {folder}'
    p4 = f'{os.getcwd()}/final_result {folder}'
    p = [p1, p2, p3, p4]
    if (file_type == "gene_bank"):
        p5 = f'{os.getcwd()}/{gb_file} {folder}'
        p.append(p5)

    for i in p:
        os.system(f'mv {i}')

    print("------       analysis done!      ------")
        

        
    
def sys_compare (seq1, seq2, seq1name = 'seq1', seq2name = 'seq2'):
    """ Function used to design aptamers for RNAs with different sequences """
    # different_seq should be a list [(seq, name of that seq), (seq, name of that seq)] 
    different_seq = two_seq_compare(seq1, seq2)
    for i in different_seq:
        a = b = 1
        if i[0] == 'seq1':
            name = seq1name + "_" + str(a)
            adt_main(name = name, input_sequence= i[1])
            a += 1 
        else: 
            name = seq2name + "_" + str(b)
            adt_main(name = name, input_sequence= i[1])
            b += 1
    
    
if __name__ == "__main__":
    usage = "usage: %prog [options]"

    #Handle the commands line options
    parser = optparse.OptionParser(usage=usage)
    parser.add_option("-a", "--alignment", help="design unique aptamers for two different RNA sequences")
    
    
#     parser.add_option("-g", "--gene_bank", help="design aptamers for gene_bank/fasta file as input")
    
#     parser.add_option("-i", "--gi", help="design aptamers for GI as input")
    
#     parser.add_option("-s", "--sequence", help="design aptamers for RNA sequence as input")
    
    
    (options, args) = parser.parse_args()
    
    
    a = options.alignment
 
    
    if len(sys.argv) == 3:
        if not sys.argv[1] in ["fasta", "gene_bank", "GI"]: 
            name = sys.argv[1]
            sequence = sys.argv[2]
            adt_main(name = name, input_sequence = sequence)
        
        
    elif len(sys.argv) == 2:
        file = sys.argv[1]
        fileName, fileExtension = os.path.splitext(file)
        if fileExtension:
            if fileExtension == '.gb':
                adt_main(file_type='gene_bank', gb_file= file)
                
            elif fileExtension == '.fa': 
                adt_main(file_type='fasta', file_name= file)
        
        else: 
            adt_main(file_type='gene_bank', GI= file)
    else:
        print ('the format of your input is incorrect, please try again')
        sys.exit(1)
        
        
    
